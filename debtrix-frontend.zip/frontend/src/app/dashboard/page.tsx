"use client";

import { useEffect, useState } from "react";
import { api, DashboardData, RepoSummary } from "@/lib/api";
import { MetricCard } from "@/components/MetricCard";
import { PriorityFixList } from "@/components/PriorityFixList";
import { RepoSelector } from "@/components/RepoSelector";

export default function DashboardPage() {
  const [repos, setRepos] = useState<RepoSummary[]>([]);
  const [selectedRepoId, setSelectedRepoId] = useState<string | null>(null);
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .getConnectedRepos()
      .then((list) => {
        setRepos(list);
        if (list.length > 0) setSelectedRepoId(list[0].id);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!selectedRepoId) return;
    setError(null);
    api
      .getLatestDashboard(selectedRepoId)
      .then(setData)
      .catch(() => setData(null)); // no scans yet is a normal state, not an error banner
  }, [selectedRepoId]);

  return (
    <main className="min-h-screen bg-ink-950 px-4 py-8 sm:px-8 sm:py-12">
      <div className="mx-auto max-w-4xl">
        <header className="mb-8">
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-paper">Debtrix</h1>
          <p className="mt-1 text-sm text-muted font-body">
            What your technical debt is actually costing you.
          </p>
        </header>

        {loading ? (
          <p className="text-muted font-body text-sm">Loading…</p>
        ) : repos.length === 0 ? (
          <EmptyState />
        ) : (
          <div className="space-y-8">
            <RepoSelector
              repos={repos}
              selectedId={selectedRepoId}
              onSelect={setSelectedRepoId}
              onScanComplete={() => {
                if (selectedRepoId) api.getLatestDashboard(selectedRepoId).then(setData);
              }}
            />

            {error && <p className="text-sm text-loss font-body">{error}</p>}

            {data ? (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <MetricCard
                    label="Health score"
                    value={data.overall_health_score ?? 0}
                    format="score"
                    accent="health"
                  />
                  <MetricCard
                    label="Monthly financial loss"
                    value={data.monthly_financial_loss ?? 0}
                    format="currency"
                    currency={data.currency}
                    accent="loss"
                  />
                  <MetricCard
                    label="Dev hours wasted / mo"
                    value={data.estimated_dev_hours_wasted_monthly ?? 0}
                    format="hours"
                    accent="gold"
                  />
                </div>

                <section>
                  <h2 className="font-display text-lg font-bold text-paper mb-3">
                    Top 3 priority fixes
                  </h2>
                  <PriorityFixList fixes={data.top_3_priority_fixes} currency={data.currency} />
                </section>
              </>
            ) : (
              <div className="rounded-lg border border-ink-700 bg-ink-900 p-8 text-center">
                <p className="text-paper font-body font-medium">No scan results yet</p>
                <p className="mt-1 text-sm text-muted font-body">
                  Run a scan above to see your health score and financial impact.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </main>
  );
}

function EmptyState() {
  return (
    <div className="rounded-lg border border-ink-700 bg-ink-900 p-8 text-center">
      <p className="text-paper font-body font-medium">No repositories connected</p>
      <p className="mt-1 text-sm text-muted font-body">
        Connect a GitHub repository to start scanning for technical debt.
      </p>
      <a
        href={api.githubLoginUrl()}
        className="mt-4 inline-block rounded-md bg-gold px-5 py-2.5 text-sm font-body font-semibold text-ink-950 hover:bg-gold-soft transition-colors"
      >
        Connect GitHub
      </a>
    </div>
  );
}
