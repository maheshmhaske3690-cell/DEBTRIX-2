"use client";

import { Suspense, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";

function CallbackHandler() {
  const router = useRouter();
  const params = useSearchParams();

  useEffect(() => {
    const token = params.get("token");
    if (token) {
      localStorage.setItem("debtrix_token", token);
      router.replace("/dashboard");
    } else {
      router.replace("/login");
    }
  }, [params, router]);

  return <p className="text-muted font-body text-sm">Signing in…</p>;
}

export default function AuthCallbackPage() {
  return (
    <main className="min-h-screen bg-ink-950 flex items-center justify-center">
      <Suspense fallback={<p className="text-muted font-body text-sm">Loading…</p>}>
        <CallbackHandler />
      </Suspense>
    </main>
  );
}
